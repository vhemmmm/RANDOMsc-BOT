#!/usr/bin/bash

apt update
apt upgrade
apt install nodejs
apt install libwebp
apt install ffmpeg
apt install wget
apt install tesseract
wget -O ~/../usr/share/tessdata/ind.traineddata "https://github.com/tesseract-ocr/tessdata/blob/master/ind.traineddata?raw=true"
npm install

echo "[*] All dependencies have been installed, please run the command \"npm start\" to immediately start the script"
