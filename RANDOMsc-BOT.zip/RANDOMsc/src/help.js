const help = (prefix, pushname) => { 
	return `         
 Hai ${pushname}, Berikut adalah beberapa fitur RANDOM BOT.
 Ada beberapa yg tidak bisa digunakan karena blm ada API KEY        
┏━━°❀ ❬ *TENTANG BOT* ❭ ❀°━━━┓
┃
┣➥ *${prefix}info*
┣➥ *${prefix}sewa*
┣➥ *${prefix}donate*
┣➥ *${prefix}owner*
┣➥ *${prefix}ping*
┣➥ *${prefix}bugreport [lapor bug]*
┣➥ *${prefix}request  [minta fitur]*
┃
┣━━━━°❀ ❬ *MEDIA* ❭ ❀°━━━━━⊱
┃
┣➥ *${prefix}sticker*
┣➥ *${prefix}tsticker*
┣➥ *${prefix}toimg*
┣➥ *${prefix}nulis*
┣➥ *${prefix}ocr*
┣➥ *${prefix}ytsearch*
┣➥ *${prefix}ytmp*
┣➥ *${prefix}ytmp3*
┣➥ *${prefix}ytmp4*
┣➥ *${prefix}tiktok*
┣➥ *${prefix}tiktokstalk*
┣➥ *${prefix}fototiktok*
┣➥ *${prefix}igstalk*
┣➥ *${prefix}image*
┣➥ *${prefix}pinterest*
┣➥ *${prefix}tts*
┣➥ *${prefix}tes*
┣➥ *${prefix}tep*
┣➥ *${prefix}ttp*
┣➥ *${prefix}meme*
┣➥ *${prefix}memeindo*
┣➥ *${prefix}ssweb*
┣➥ *${prefix}walpaperhd*
┣➥ *${prefix}randomcat*
┣➥ *${prefix}joox*
┣➥ *${prefix}inu*
┣➥ *${prefix}elang*
┣➥ *${prefix}unta*
┣➥ *${prefix}anjing*
┣➥ *${prefix}babi*
┣➥ *${prefix}playstore*
┣➥ *${prefix}url2img*
┣➥ *${prefix}imoji*
┣➥ *${prefix}wait*
┃
┣━━━━°❀ ❬ *CREATOR* ❭ ❀°━━━━⊱
┃
┣➥ *${prefix}thunder*
┣➥ *${prefix}tahta*
┣➥ *${prefix}glitch <teks|teks>*
┣➥ *${prefix}phlogo <teks|teks>*
┣➥ *${prefix}wolflogo <teks|teks>*
┣➥ *${prefix}quotemaker <tx|wtrmk|tema>*
┣➥ *${prefix}galaxtext*
┣➥ *${prefix}testing*
┣➥ *${prefix}tesss*
┣➥ *${prefix}textdark*
┣➥ *${prefix}textblue*
┣➥ *${prefix}textsky*
┣➥ *${prefix}texteng*
┣➥ *${prefix}lovemake*
┣➥ *${prefix}stiltext*
┣➥ *${prefix}ninjalogo*
┣➥ *${prefix}party*
┣➥ *${prefix}rtext*
┣➥ *${prefix}water*
┣➥ *${prefix}lionlogo <teks|teks>*
┣➥ *${prefix}textscreen*
┣➥ *${prefix}text3d*
┣➥ *${prefix}epep*
┣➥ *${prefix}marvelogo <teks|teks>*
┣➥ *${prefix}snowrite <teks|teks>*
┣➥ *${prefix}firetext*
┃
┣━━━°❀ ❬ *FUN&GAMES* ❭ ❀°━━━⊱
┃
┣➥ *${prefix}truth*
┣➥ *${prefix}dare*
┣➥ *${prefix}tebakgambar*
┣➥ *${prefix}family100*
┣➥ *${prefix}caklontong*
┣➥ *${prefix}game*
┣➥ *${prefix}jodoh*
┣➥ *${prefix}ramaljadian*
┣➥ *${prefix}mlherolist*
┣➥ *${prefix}bucin*
┣➥ *${prefix}persengay*
┣➥ *${prefix}ramalhp <nomor>*
┣➥ *${prefix}ceckjodoh*
┣➥ *${prefix}fakerepaly*
┣➥ *${prefix}but*
┃
┣━━━━━°❀ ❬ *ANIME* ❭ ❀°━━━━━⊱
┃
┣➥ *${prefix}openanime*
┣➥ *${prefix}Naruto*
┣➥ *${prefix}Minato*
┣➥ *${prefix}Boruto*
┣➥ *${prefix}Hinata*
┣➥ *${prefix}Sakura*
┣➥ *${prefix}Sasuke*
┣➥ *${prefix}kaneki*
┣➥ *${prefix}toukacan*
┣➥ *${prefix}rize*
┣➥ *${prefix}akira*
┣➥ *${prefix}itori*
┣➥ *${prefix}kurumi*
┣➥ *${prefix}miku*
┣➥ *${prefix}anime*
┣➥ *${prefix}nekonime*
┣➥ *${prefix}loli*
┣➥ *${prefix}loli2*
┣➥ *${prefix}waifu*
┣➥ *${prefix}imagetest*
┣➥ *${prefix}wibu*
┣➥ *${prefix}randomanime*
┣➥ *${prefix}pokemon*
┣➥ *${prefix}artinama*
┃
┣━━°❀ ❬ *INFO&EDUKASI* ❭ ❀°━━⊱
┃
┣➥ *${prefix}infogc*
┣➥ *${prefix}infogempa*
┣➥ *${prefix}infogithub*
┣➥ *${prefix}infocuaca*
┣➥ *${prefix}infonomor*
┣➥ *${prefix}infomobil*
┣➥ *${prefix}infomotor*
┣➥ *${prefix}grupinfo*
┣➥ *${prefix}lirik*
┣➥ *${prefix}quotes*
┣➥ *${prefix}kbbi*
┣➥ *${prefix}cerpen*
┣➥ *${prefix}chord*
┣➥ *${prefix}wiki*
┣➥ *${prefix}brainly*
┣➥ *${prefix}resepmasakan*
┣➥ *${prefix}map*
┃
┣━━━━━°❀ ❬ *GRUP* ❭ ❀°━━━━━⊱
┃
┣➥ *${prefix}add*
┣➥ *${prefix}kick*
┣➥ *${prefix}promote*
┣➥ *${prefix}demote*
┣➥ *${prefix}setname*
┣➥ *${prefix}setdesc*
┣➥ *${prefix}welcome*
┣➥ *${prefix}nsfw*
┣➥ *${prefix}simi*
┣➥ *${prefix}simih*
┣➥ *${prefix}gc [buka/tutup]*
┣➥ *${prefix}tagme*
┣➥ *${prefix}hidetag*
┣➥ *${prefix}tagall*
┣➥ *${prefix}otagall*
┣➥ *${prefix}fitnah*
┣➥ *${prefix}infogc*
┣➥ *${prefix}groupinfo*
┣➥ *${prefix}linkgroup*
┣➥ *${prefix}listadmins*
┣➥ *${prefix}openanime*
┣➥ *${prefix}edotense*
┣➥ *${prefix}kudeta*
┃
┣━━━━━°❀ ❬ *NSFW* ❭ ❀°━━━━━⊱
┃
┣➥ *${prefix}nsfwloli*
┣➥ *${prefix}nsfwblowjob*
┣➥ *${prefix}nsfwneko*
┣➥ *${prefix}nsfwtrap*
┣➥ *${prefix}randomhentai*
┣➥ *${prefix}hentai*
┣➥ *${prefix}indohot*
┃
┣━━━━°❀ ❬ *KERANG* ❭ ❀°━━━━━⊱
┃
┣➥ *${prefix}apakah*
┣➥ *${prefix}kapankah*
┣➥ *${prefix}bisakah*
┣➥ *${prefix}rate*
┣➥ *${prefix}watak*
┣➥ *${prefix}hobby*
┃
┣━━━━━°❀ ❬ *OTHER* ❭ ❀°━━━━━⊱
┃
┣➥ *${prefix}blocklist*
┣➥ *${prefix}testime*
┣➥ *${prefix}hilih*
┣➥ *${prefix}say*
┣➥ *${prefix}bapakfont*
┣➥ *${prefix}delete*
┣➥ *${prefix}shorturl*
┃
┣━━━━°❀ ❬ *OWNER* ❭ ❀°━━━━━⊱
┃
┣➥ *${prefix}setprefix*
┣➥ *${prefix}bc*
┣➥ *${prefix}ban*
┣➥ *${prefix}block*
┣➥ *${prefix}unblock*
┣➥ *${prefix}clearall*
┣➥ *${prefix}clone*
┣➥ *${prefix}getses*
┣➥ *${prefix}setpp*
┣➥ *${prefix}setpp*
┣➥ *${prefix}leave*
┃
┣━━━━━━━━━━━━━━━━━━━━
┃ *$POWERED BY RANDOMsc*
┗━━━━━━━━━━━━━━━━━━━━`
}
exports.help = help
